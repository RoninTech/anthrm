
AntHRM: Realtime heart rate readout with graph.
Version v1.1

Requires 64bit Windows and an Ant+ USB dongle with the libusb0 drivers preinstalled (default with Garmin ANT Agent installed).



Michael McElligott
-----------------
http://mylcd.sourceforge.net
okio@users.sourceforge.net