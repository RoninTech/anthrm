Based on program by:

Michael McElligott
-----------------
http://mylcd.sourceforge.net
okio@users.sourceforge.net

- Added zones, calories, burn rate, workout duration, workout average etc.
- Added settings.ini configuration to change background image (should be a 320x240 png image)
- Added export of workout data to CSV file if export option is enabled in settings.ini

- Function that calculates the clients maximum HRT based on function from wikipedia: HRmax = 191.5 - (0.007 � age^2)  See: http://en.wikipedia.org/wiki/Heart_rate#Formula
- Function that sets the various zones based on the client's calculated maximum HRT.  See http://en.wikipedia.org/wiki/File:Exercise_zones.png

- Function to calculate the calories used since the last HRT reading and track the total taken from "Prediction of energy expenditure from heart rate monitoring during submaximal exercise", L. R. KEYTEL, J. H. GOEDECKE, T. D. NOAKES, H. HIILOSKORPI, R. LAUKKANEN, L. VAN DER MERWE, & E. V. LAMBERT that was published in the Journal of Sports Sciences.
Male: ((-55.0969 + (0.6309 x HR) + (0.1988 x W) + (0.2017 x A))/4.184) x 60 x T
Female: ((-20.4022 + (0.4472 x HR) - (0.1263 x W) + (0.074 x A))/4.184) x 60 x T
HR = Heart rate (in beats/minute) - using average HR for this so it could go up and down as workout changes.
W = Weight (in kilograms)
A = Age (in years)
T = Exercise duration time (in hours)